﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project3
{
    public class Enumerations
    {
        public enum Major
        {
            CPSC,
            CPEG,
            ELEG,
            MATH
        }

        public enum StudentType
        {
            UG,
            GRAD
        }
    }
}
