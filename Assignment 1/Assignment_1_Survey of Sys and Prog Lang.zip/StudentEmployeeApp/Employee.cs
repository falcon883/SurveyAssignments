﻿namespace StudentApp
{
    internal class Employee
    {
        private string firstName;
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        private string lastName;
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        private int empID;
        public int EmpID
        {
            get { return empID; }
            set { empID = value; }
        }

        private double hoursWorked;
        public double HoursWorked
        {
            get { return hoursWorked; }
            set { hoursWorked = value; }
        }

        private double payRate;
        public double PayRate
        {
            get { return payRate; }
            set { payRate = value; }
        }

        private const double STANDARD_WORK_WEEK = 40.0;
        private const double OVERTIME_MULTIPLIER = 1.5;

        public double ComputePay()
        {
            double totalPay = 0;

            if (hoursWorked <= STANDARD_WORK_WEEK)
            {
                // No overtime - regular pay only
                totalPay = hoursWorked * payRate;
            }
            else
            {
                // Overtime calculation
                double overtimeHours = hoursWorked - STANDARD_WORK_WEEK;
                double overtimeRate = payRate * OVERTIME_MULTIPLIER;

                totalPay = (STANDARD_WORK_WEEK * payRate) + (overtimeHours * overtimeRate);
            }

            return totalPay;
        }

        public double ComputeOvertimePay()
        {
            if (hoursWorked > STANDARD_WORK_WEEK)
            {
                double overtimeHours = hoursWorked - STANDARD_WORK_WEEK;
                double overtimeRate = payRate * OVERTIME_MULTIPLIER;
                return overtimeHours * overtimeRate;
            }
            return 0; // No overtime
        }

        public bool HasOvertime()
        {
            return hoursWorked > STANDARD_WORK_WEEK;
        }
    }
}